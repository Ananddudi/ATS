import React,{ useEffect } from 'react';
import {useApi} from './contextapi';
const Error = () => {
const {shownav} = useApi()
useEffect(()=>{
  shownav(true)
},[])
    return (
      <>
      <div className='container container-table'>
      <div className="position-absolute h-100 row align-items-center">
        <h1>Unauthorized</h1>
      </div>
      </div>
      </>
    );
  };

  export default Error;