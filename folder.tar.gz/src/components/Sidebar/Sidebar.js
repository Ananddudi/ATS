
import { useState } from "react";
import { NavLink as NavLinkRRD, Link} from "react-router-dom";


import {
  Collapse,
  Navbar,
  NavItem,
  NavLink,
  Nav,
  Container,
} from "reactstrap";

import {useApi} from '../../views/examples/contextapi' 
import {useHistory} from 'react-router-dom'


const Sidebar = (props) => {

  const {logout,auth,idchange,updatingobj} = useApi()


  const [collapseOpen, setCollapseOpen] = useState();
  // verifies if routeName is the one active (in browser input)
  // const activeRoute = (routeName) => {
  //   return props.location.pathname.indexOf(routeName) > -1 ? "active" : "";
  // };
  // toggles collapse between opened and closed (true/false)
  // const toggleCollapse = () => {
  //   setCollapseOpen((data) => !data);
  // };
  // closes the collapse

  const history = useHistory()
  const closeCollapse = () => {
    setCollapseOpen(false);
  };
  // creates the links that appear in the left menu / Sidebar
  const createLinks = (routes) => {
    return routes.map((prop, key) => {
      if(auth){
        if(prop.name === 'Login' || prop.name === 'Register'){
          return
        }
      }
      return (
        <NavItem key={key}>
          <NavLink
            to={prop.layout + prop.path}
            tag={NavLinkRRD}
            onClick={()=>{
              closeCollapse()
              idchange('')
              updatingobj('')
            }}
            activeClassName="active"
          >
            <i className={prop.icon} />
            {prop.name}
          </NavLink>
        </NavItem>
      );
    });
  };

  const {routes, logo } = props;
  let navbarBrandProps;
  if (logo && logo.innerLink) {
    navbarBrandProps = {
      to: logo.innerLink,
      tag: Link,
    };
  } else if (logo && logo.outterLink) {
    navbarBrandProps = {
      href: logo.outterLink,
      target: "_blank",
    };
  }

  const directing = ()=>{
    return setTimeout(()=>{
      return "/auth/login"
    },1000)
  }

  return (
    <Navbar
      className="navbar-vertical fixed-left navbar-light bg-white"
      expand="md"
      id="sidenav-main"
    >
      <Container fluid>

        <Collapse navbar isOpen={collapseOpen}>

          <Nav navbar>{createLinks(routes)}</Nav>
          <Nav navbar>
          <NavItem>
          <NavLink
            to={directing}
            tag={NavLinkRRD}
            onClick={()=>{
              logout()
              closeCollapse()
              setTimeout(()=>{
                history.push("auth/login")
              },2000)
            }
              }
            activeClassName="active"
          >
            <i className="ni ni-circle-08 text-pink" />
            Logout
          </NavLink>
        </NavItem></Nav>
          {/* Divider */}
          <hr className="my-3" />
          {/* Heading */}
          {/* Navigation */}
        </Collapse>
      </Container>
    </Navbar>
  );
};

export default Sidebar;
