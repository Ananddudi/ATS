import React,{useEffect, useState} from 'react';
import './App.css';
import Tesseract from 'tesseract.js';
import {Line} from 'rc-progress';
import FileBase64 from 'react-file-base64';

function App() {
  const [data,setData] = useState('no data')
  const [file,setFile] = useState(null)
  const [probar,setProbar] = useState(0)
  const [pdf,setPdf] = useState(null)


  const handlefile = (event)=>{
    setFile(event.target.files[0])
  }

  const execute = (e)=>{
    e.preventDefault()
    if(file){
      let fileis = window.URL.createObjectURL(file)
      Tesseract.recognize(
        fileis,
        'eng',
          { logger: m => setProbar((m.progress)*100) }
        ).then(({ data: { text } }) => {
          setData(text)
        })
    }
  }

  useEffect(()=>{
    if(pdf){
      // console.log('file',pdf[0].base64.split(',')[1])
    const fetchapi = async()=>{
      var objis = await {
        "Parameters": [
            {
                "Name": "File",
                "FileValue": {
                    "Name": pdf[0].name,
                    "Data": pdf[0].base64.split(',')[1]
                }
            },
            {
                "Name": "StoreFile",
                "Value": "true"
            }
        ]
    }

      const vall = await fetch('https://v2.convertapi.com/convert/pdf/to/txt?Secret=EO2wgnyqnZc5Tt3H',{
        method:'POST',
        headers:{
          'Content-Type': 'application/json'
        },
        body:JSON.stringify(objis)
      })
      const vv = await vall.json()
      window.location = vv.Files[0].Url
    }
    fetchapi()
  }
  },[pdf])
  // const postfile = async(e)=>{
  //   e.preventDefault()
  //   var formdata = new FormData();
  //   formdata.append("filename", file);
  //   formdata.append("output_format", "txt");
  //   formdata.append("language", "eng");

  //   var requestOptions = {
  //     method: 'POST',
  //     mode:'no-cors',
  //     body: formdata,
  //   };

  //   const value = await fetch("https://api.ocrconvert.com/v1/convert?api_token=HpHbcwJ16vd3BJlkIp735xuAtgk3q3WhvHzM2agu1LimuyJNdeBPYRm8FPUw", requestOptions)
  //   console.log('value',value)
  //   const b = await value.data.json()
  //   console.log('b',b)
  // }

  return (
    <div className="App">
      <header className="App-header">
        <form className="flexboxes">
          <label htmlFor="afile">Upload a file</label>
          <input style={{marginTop:"5%"}} type="file"  onChange={handlefile}/>
          <input style={{marginTop:"5%"}} type="submit" value="submit" onClick={execute}/>
        </form>
        <div style={{width:"20%"}}>
          <Line percent={probar} strokeWidth="2" strokeColor="green" />
        </div>
        <span style={{marginTop:"5%",width:"100%",height:"30%"}}>{data}</span>
        {/* <footer style={{float:'right'}}>Developer Bazaar Technologies</footer> */}
      </header>
      <div>
      <FileBase64
        className="base42class"
        multiple={ true }
        onDone={(ff)=>setPdf(ff)}
        />
      </div>
    </div>
  );
}

export default App;
