import React,{useState,useEffect} from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import {useApi} from './contextapi';
import { motion } from "framer-motion"
import {Card,CardBody,CardTitle,Col,CardHeader,Container,Row} from 'reactstrap'



ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

  export const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: "Candidate's Data",
      },
    },
  };
  
  const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July','August','September','October','November','December'];

  
const Report = () => {
  const {shownav,userdata,goal} = useApi()
  const [userinfo,setUserinfo] = useState({
    interview:'',
    scanning:'',
    onboard:'',
    newjobs:''
  })

  useEffect(()=>{
    return shownav(false)
  },[shownav])

  const data = {
    labels,
    datasets: [
      {
        label: 'Interviewed',
        data: [2,3,5,6,7,6,8],
        backgroundColor: 'coral',
      },
      {
        label: 'New Jobs',
        data: [2,3,5,9,3,5,7,4,9],
        backgroundColor: 'teal',
      },
      {
        label: 'Onboard',
        data: [2,3,5,6,7,6,9],
        backgroundColor: 'maroon',
      },
      {
        label: 'Scanning',
        data: [2,3,5,6,7,6,9],
        backgroundColor: 'orange',
      }
    ],
  };
  

  useEffect(()=>{
    //for candidates
    let inter = 0
    let scans = 0
    let newjob = 0
    let onb = 0
    if(userdata){
        for(const i of userdata){
          if(i.status){
            i.status === 'Interviewed' && (inter += 1)
            i.status === 'Onboard' && (onb += 1)
            i.status === 'New Jobs' && (newjob += 1)
            i.status === 'Scanning' && (scans += 1)
          }
        }
        setUserinfo({
          interview:inter,
          scanning:scans,
          onboard:onb,
          newjobs:newjob
        })
    }
  },[userdata])

  return (
    <>
      <Container className="pt-7 bg-gradient-info pb-2" fluid>
      <div className='mt-1 ml-3 mb-4' >
      <Row>
        <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
        >
          <Card 
          className="card-stats ">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Total Candidate
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">
                          {userdata.length}              
                        </span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-danger text-white rounded-circle shadow">
                          <i className="fas fa-chart-bar" />
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
                </motion.div>
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Card className="card-stats ml-3">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Goals
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">
                          {goal?goal.goals:0}             
                        </span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-danger text-white rounded-circle shadow">
                          <i className="fas fa-chart-bar" />
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
                </motion.div>
                </Row>
                </div>
          <div>
            <Card className="shadow">
              <CardHeader className="border-0">
                <h3 className="mb-0">Report of candidates</h3>
              </CardHeader>
              <Bar options={options} data={data} />
            </Card>
          </div>         
          
      </Container>
    </>
  );
};

export default Report;
