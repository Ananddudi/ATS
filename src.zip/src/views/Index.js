
// import { useState } from "react";
// // node.js library that concatenates classes (strings)
// import classnames from "classnames";
// // javascipt plugin for creating charts
// // import Chart from "chart.js";
// // react plugin used to create charts
// import { Line, Bar } from "react-chartjs-2";
// // reactstrap components
// import {
//   Button,
//   Card,
//   CardHeader,
//   CardBody,
//   NavItem,
//   NavLink,
//   Nav,
//   Progress,
//   Table,
//   Container,
//   Row,
//   Col,
// } from "reactstrap";



import Header from "components/Headers/Header.js";
import {Redirect} from "react-router-dom";
import {useApi} from './examples/contextapi';

const Index = (props) => {
  const {auth} = useApi()

  return (
    <>
      {
        auth ? <Header /> : <Redirect to="/auth/login"/>
      } 
    </>
  );
};

export default Index;
