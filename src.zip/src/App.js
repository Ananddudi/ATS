
import './App.css';



function App() {
  return (
    <div className="App">
      <h1>Developer Bazaar</h1>
    </div>
  );
}

export default App;
