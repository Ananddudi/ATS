import React,{useEffect, useState} from 'react';
import './App.css';
import Tesseract from 'tesseract.js';
import {Line} from 'rc-progress';
import FileBase64 from 'react-file-base64';

function App() {
  const [data,setData] = useState('Data will be shown here')
  const [file,setFile] = useState(null)
  const [probar,setProbar] = useState(0)
  const [pdf,setPdf] = useState(null)


  const handlefile = (event)=>{
    setFile(event.target.files[0])
  }

  const execute = (e)=>{
    e.preventDefault()
    if(file){
      setProbar(0)
      setData('Compiling...')
      let fileis = window.URL.createObjectURL(file)
      Tesseract.recognize(
        fileis,
        'eng',
          { logger: m => setProbar((m.progress)*100) }
        ).then(({ data: { text } }) => {
          setData(text)
        })
    }
  }

  const executepdf = ()=>{
    if(pdf){
      // console.log('file',pdf[0].base64.split(',')[1])
    setProbar(0)
    setData('Compiling...')
    const fetchapi = async()=>{
      var objis = await {
        "Parameters": [
            {
                "Name": "File",
                "FileValue": {
                    "Name": pdf[0].name,
                    "Data": pdf[0].base64.split(',')[1]
                }
            },
            {
                "Name": "StoreFile",
                "Value": "true"
            }
        ]
    }
      setProbar(50)
      const vall = await fetch('https://v2.convertapi.com/convert/pdf/to/txt?Secret=EO2wgnyqnZc5Tt3H',{
        method:'POST',
        headers:{
          'Content-Type': 'application/json'
        },
        body:JSON.stringify(objis)
      })
      setProbar(80)
      const vv = await vall.json()
      setProbar(87)
      const readingfile = await fetch(vv.Files[0].Url)
      const response = await readingfile.text()
      setProbar(100)
      setData(response)
    }
    fetchapi()
  }
  }


  return (
    <div className="App">
      <header className="App-header">
      <section style={{display:"flex",flexDirection:"row",justifyContent:"space-between"}}>
        <div style={{marginRight:"5%"}}>
        <h4>For Image</h4>
        <form className="flexboxes">
          <input style={{marginTop:"5%"}} type="file"  onChange={handlefile}/>
          <input style={{marginTop:"5%"}} type="submit" value="submit" onClick={execute}/>
        </form>
        </div>
        <div style={{marginLeft:"5%",marginTop:"1%"}}>
        <h4>For PDF</h4>
        <FileBase64
        className="base42class"
        multiple={ true }
        onDone={(ff)=>setPdf(ff)}
        />
        <button style={{width:"100%",marginTop:"5%"}} onClick={executepdf}>Submit</button>
        </div>
        </section>
        <div style={{width:"50%",marginTop:"1%"}}>
          <Line percent={probar} strokeWidth="1" strokeColor="green" />
        </div>
        <span style={{marginTop:"5%",width:"100%",height:"30%"}}>{data}</span>
      </header>
    </div>
  );
}

export default App;
